  __  __ _      __  __           _
 |  \/  (_)    |  \/  |         | | 2022
 | \  / |___  _| \  / | ___   __| |___
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/


=======   MixMods.com.br   ======= - Best visualization with monospaced fonts, like "Consolas".


------- Instructions:

Extract the folder "Improved Streaming" to your ModLoader folder.

In the "(settings)" folder there are other options. Just replace the ".ini" file in the mod folder.
All settings have "RemoveUnusedWhenPercent" enabled.
If you use HD mods, like RoSA, use from the folder "0a" or increase "StreamMemoryForced".
For SAMP, any works, but "1" seems more useful.

-- Essentials Pack download: https://www.mixmods.com.br/2019/06/sa-essentials-pack/
-- RECOMMENDED Open Limit Adjuster (or other limit adjuster well configured): https://www.mixmods.com.br/2015/02/open-limit-adjuster/
-- If using MixSets, use the latest version.


 == ATTENTION:
This can delay the game's loading time, depending on the configuration you use.
You can bypass the mod by holding SHIFT, or just wait, even if the game seems frozen.
In case of problems, use "2 - LODs only" which is less intrusive and also helps a lot.
This mod is a new version of "Load Whole Map".


Version: v1.0.1
--------------------

Author: Junior_Djjr
Credits: ThirteenAG


====   MixMods.com.br                ====
====   fb.com/FamiliaMixMods         ====
====   youtube.com/JuniorDjjrMixMods ====
