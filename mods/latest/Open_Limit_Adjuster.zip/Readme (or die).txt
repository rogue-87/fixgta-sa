  __  __ _      __  __           _     
 |  \/  (_)    |  \/  |         | | 2022
 | \  / |___  _| \  / | ___   __| |___ 
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/
                                       

=======   MixMods.com.br   ======= - Best visualization with monospaced font, as "Consolas".


------- Instructions:

Exctract the folder "Open Limit Adjuster" to your ModLoader folder of your GTA III, VC ou SA.

= Folder (settings):
(Project2DFX) - For Project2DFX (already include the same file in its download).
(SAMP) - For SAMP with many players (probably not needed on small servers).
(SAMP + Project2DFX) - For SAMP with many players, and Project2DFX.

If this is not your case, simply install the mod normally, it already increases the limits in a good way and without exaggeration.

-- Download of Essentials Pack SA: https://www.mixmods.com.br/2019/06/sa-essentials-pack/
-- Download of Essentials Pack VC: https://www.mixmods.com.br/2020/08/vc-essentials-pack/
-- Download of Essentials Pack III: https://www.mixmods.com.br/2020/12/iii-essentials-pack/


          
 = CONFLICT WARNING:
BE CAREFUL TO DON'T HAVE 2 INSTALLED AT THE SAME TIME!!! There are some mods (like Project2DFX) that already come with this mod.
The old name of the Open Limit Adjuster files are: "limit_adjuster_gta3vcsa". If you have it, delete and install this one!


 = fastman92's limit adjuster:
If you use FLA together with OLA, it's recommended that you disable the settings for one of them because they cause conflicts when using the same settings.
Just open the .ini and put "#" at the beginning of the line to deactivate a function. Try to give priority to the Open Limit Adjuster, since it adjusts the limits automatically.
If your game is working normally with both installed, you probably don't need to change anything.


 = Command:
Press F5 within the game to view information. Also serves to test if the mod is working properly.
The command can be changed inside the .ini if you think it will bother you.

 

Version: v1.5.9 (III, VC, SA)
--------------------

Authors: LINK/2012, ThirteenAG, Blackbird88
More contributions: aap, DK22Pac, fastman92, maxorator, Silent, Wesser, Junior_Djjr


====   MixMods.com.br         ====
====   fb.com/FamiliaMixMods  ====

