  __  __ _      __  __           _     
 |  \/  (_)    |  \/  |         | | 2022
 | \  / |___  _| \  / | ___   __| |___ 
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/
                                       

=======   MixMods.com.br   ======= - Best visualization with monospaced fonts, like "Consolas".


------- Instructions:

Extract the folder "FramerateVigilante" to your Modloader folder.

-- Download the latest version of Modloader: https://www.mixmods.com.br/2018/01/modloader/
-- This mod is already included in Essentials Pack: https://www.mixmods.com.br/2020/08/vc-essentials-pack/
-- Only for 1.0 game version, if required, downgrade it: https://www.mixmods.com.br/2021/09/primeiros-passos-para-montar-um-gta-modificado/#Downgrade


 The mod comes with .ini file to set up the FPS limit (just like MixSets), by default, 60 FPS.
 Remember to keep frame limiter enabled on game menu.


Version: 14/08/22 (MM/DD/YY)
--------------------

Author: Junior_Djjr
Contributions: ThirteenAG, HzanRsxa2959, martonp96, 0x416c69


====   MixMods.com.br                ====
====   fb.com/FamiliaMixMods         ====
====   youtube.com/JuniorDjjrMixMods ====

