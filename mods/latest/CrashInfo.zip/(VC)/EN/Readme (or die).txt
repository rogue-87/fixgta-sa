  __  __ _      __  __           _
 |  \/  (_)    |  \/  |         | | 2022
 | \  / |___  _| \  / | ___   __| |___
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/


=======   MixMods.com.br   ======= - Best visualization with monospaced fonts, like "Consolas".


------- Instructions:

Extract all files from the folder "(mod - to the game folder)" to your GTA VC folder (where the .exe is).
Can't be installed on ModLoader, as this mod needs to be loaded first.

-- Essentials Pack download: https://www.mixmods.com.br/2020/08/vc-essentials-pack/

The mod automatically updates the "CrashList.txt" file based on: https://github.com/JuniorDjjr/CrashInfo/tree/main/Lists
In the file "CrashInfo.ini" there are some language, update and connection options.
By default, it will update the "CrashList.txt" file once a day when starting the game.

Recommended to use together with SCRLog: https://www.mixmods.com.br/2020/09/scrlog.html


Version: v1.2 VC
--------------------

Author: Junior_Djjr
Crash list built by Junior_Djjr and MixMods community.


====   MixMods.com.br                ====
====   fb.com/FamiliaMixMods         ====
====   youtube.com/JuniorDjjrMixMods ====
