  __  __ _      __  __           _     
 |  \/  (_)    |  \/  |         | | 2021
 | \  / |___  _| \  / | ___   __| |___ 
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/
                                       

=======   MixMods.com.br   ======= - Best visualization with monospaced font, as "Consolas".


------- Instructions:

Exctract the folder "Project2DFX" to your Modloader folder.

-- Download the latest version of Modloader: MixMods.com.br/2015/01/SA-Modloader.html


IF YOU ALREADY HAVE "OPEN LIMIT ADJUSTER" INSTALLED, DESINSTALL IT!
This mod already comes with Open Limit Adjuster configured for it, so is required to desinstall any other that you have and keep this.
You will not lose anything with it. The mod of original OLA files are "limit_adjuster_gta3vcsa.asi" or "III.VC.SA.LimitAdjuster.asi".
Remembering that Open Limit Adjuster is incompatible with SOME settings of fastman92 limit adjuster.


== Notes ==
 You can open the file "SALodLights.ini" to configure with you taste. - TUTORIAL: MixMods.com.br/2016/03/tutorial-como-configurar-o-project2dfx.html

 In the "(settings)" folder there are some settings options.

 If you don't have that light effects on lampposts, disable "RenderSearchlightEffects"! (put "0")

 If objects flickering, open "III.VC.SA.LimitAdjuster.ini" and increase "MemoryAvailable". (or "StreamMemory" from MixSets)



Version: v4.4 (FestiveLights = 0; LoadAllBinaryIPLs = 0)
--------------------

Author: ThirteenAG, TJGM
Credits: Silent, _DK, Wesser, fastman92, LINK/2012, maxorator;


====   MixMods.com.br         ====
====   fb.com/FamiliaMixMods  ====

