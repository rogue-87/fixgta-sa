  __  __ _      __  __           _     
 |  \/  (_)    |  \/  |         | | 2023
 | \  / |___  _| \  / | ___   __| |___ 
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/
                                       

=======   MixMods.com.br   ======= - Best visualization with monospaced fonts, like "Consolas".


------- Instructions:

Extract the folder "CLEO" to your GTA SA directory.

-- At least CLEO 4.4 is required: https://www.mixmods.com.br/2020/10/biblioteca-cleo-4-4/
   Otherwise there will be an error message about ordinal number.


 = If you create CLEO mods:
https://forum.mixmods.com.br/f141-gta3script-cleo/t5206-como-criar-scripts-com-cleoplus
https://library.sannybuilder.com/#/sa/CLEO%2B

 = Replaces the need for:
ClipboardCommands.cleo (full)
CoopOpcodes.cleo (full)
newOpcodes.cleo (partial)


Version: v1.2.0
--------------------

Author: Junior_Djjr
Parts from newOpcodes.cleo: DK22Pac
Thanks to: plugin-sdk contributors


====   MixMods.com.br                ====
====   fb.com/FamiliaMixMods         ====
====   youtube.com/JuniorDjjrMixMods ====

