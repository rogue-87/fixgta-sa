  __  __ _      __  __           _     
 |  \/  (_)    |  \/  |         | | 2021
 | \  / |___  _| \  / | ___   __| |___ 
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/
                                       

=======   MixMods.com.br   ======= - Best visualization in Notepad with monospaced font, as "Consolas".


------- Instructions:

Extract the files to any folder inside Modloader folder. Or if you prefer to your "Scripts" folder or GTA SA directory.

-- Download the latest version of Modloader: MixMods.com.br/2015/01/SA-Modloader.html


 You can edit .ini file to configure things like hud size, force resolution, control fov etc.


Version: 27/09/18 (DD/MM/YY)
--------------------

Author: ThirteenAG


====   MixMods.com.br         ====
====   fb.com/FamiliaMixMods  ====

