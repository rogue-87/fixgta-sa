  __  __ _      __  __           _     
 |  \/  (_)    |  \/  |         | | 2021
 | \  / |___  _| \  / | ___   __| |___ 
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/
                                       

=======   MixMods.com.br   ======= - Best visualization with monospaced font, as "Consolas".


------- Instructions:

Extract the folder "SkyGfx" to your Modloader folder.

In the "(settings)" folder there are other settings options.

-- Download the latest version of Modloader: MixMods.com.br/2015/01/SA-Modloader.html



---- INTRODUCTION:
Inside the folder you have 3 .ini files:
skygfx1.ini = PS2 settings
skygfx2.ini = PC settings
skygfx3.ini = Mobile settings

The setting on the file "skygfx1.ini" is loaded when you load the game, which is originally PS2 settings.

Pressing F10, the current setting will change into "skygfx2.ini", "skygfx3.ini" etc. The mod will load up to "skygfx9.ini".
Pressing F11, all .ini files will be reloaded, so you can edit the files without restarting the game.
Remember that ; in the start of the line means "configuration disabled". Remove/put it to enable/disable the options.
You can change the commands on "keySwitch" and "keyReload".
Do note that some stuff doesn't change without exiting the game. Are warned on .ini as "(cannot be toggled at runtime)".



---- Problems:
- Doesn't work on SAMP:
Disable the "buildingPipe" in .ini and use SAMP Graphic Restore Fix: MixMods.com.br/2014/12/samp-graphic-restore-fix-correcao-de.html

- The game runs but with black screen
You are using old Real Linear Graphics, update it.

- Crash when using Shadows Extender:
Disable the functions: pedShadows and stencilShadows

- Crash when entering the game:
Possibly you use some vegetation/grass mod. Keep "ps2grassFiles=0" on the SkyGfx's .ini.

- Objects of map mods too light:
Comment the "explicitBuildingPipe" line in the .ini (putting one ; at the beginning of line). This function works poorly with the ZModeler exporter.

- Nothing helped me:
It's recommended to you rename (or copy all the content) from "skygfx2.ini" to "skygfx1.ini". So the mod will load the original graphics of the game (with few alterations).
If works in this way, may you have some other incompatible mod. You may try to identify which, or simply configure the file, slowly, as you want until you find the incompatible function.



---- FAQ:

- Car reflections:
The name of the configuration on .in is "vehiclePipe". There are the options names on that line.

- I don't like the orange color:
Disable or change the "colorFilter" configuration to PC or Mobile.

- My game is lagged:
Change vehiclePipe to another, such as PC, PS2 or Spec. You can also try reducing "envMapSize" to 64 or 32.
Also change "radiosity=Shader" to "radiosity=PS2" if you do not use an offboard graphics card.

- The shadows doesn't change on the game menu:
Disable the functions "pedShadows" and "stencilShadows" on the .ini (put it ; in the start of the line to disable the shadow disabling).

- Disable the blurring
Search for all "blur" ("blurLeft" etc) of the .ini file and put it all "0".

- Alpha/transparency fix:
The "DualPass" setting greatly improves alpha transparency with low FPS loss.
In addition, look for the "; zwriteThreshold=128" line, remove the ";" and set it for example "zwriteThreshold=255" to have a better effect, especially on vegetation.
However using 255 currently causes some bugs (eg letters from traffic signs fading), I recommend that you use something like "zwriteThreshold=200".

- The "Neo" reflection is too much blue:
Lower the value in "neoShininess" to about 0.5 or less.

- The sun is still small / doesn't have lensflare:
You can increase the sun size with several ways, as using MixSets (function SunSize) or using PS2's Seabed that can find in the original post of MixMods.
If you don't have the sun lensflare in your game, may some mod disabled, or you aren't using the more recent version of SilentPatch (that fixes the lensflare not working in some graphic cards)

- Detail maps is blurry:
Download and install "HD details" from MixMods, important for HD textures pack use.



---- SilentPatch:
SilentPatch is recommended. If you DON'T use it, you will need to rename your "data\timecycp.dat" into "timecyc.dat" to use it as timecycle. Or remove the ; in the line usePCTimecyc=1



---- Vehicles:
The PS2 reflection doesn't work well on original PC vehicles (adds too much reflection).
You can download the vehicles converted from PS2 in the original post: MixMods.com.br/2015/06/skygfx-graficos-do-ps2-para-pc.html
Some vehicles as Sadler simply doesn't have reflections. Also, it's necessary to change such vehicles to have reflections, and PS2 vehicles also fix it, or the ISDC mod:
You may want to download the fixed original vehicles (Improved SA Default Vehicles) here: MixMods.com.br/2015/08/improved-sa-default-cars-carros-originais-melhorados.html



Version: v4.2b
--------------------

Author: The Hero (aap)
Credits: ThirteenAG, NTAuthority, Silent, DexX
Fix Wood Blood Drops.cs: Junior_Djjr


====   MixMods.com.br         ====
====   fb.com/FamiliaMixMods  ====

